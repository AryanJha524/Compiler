#ifndef __VIRTUALMACHINE_H
#define __VIRTUALMACHINE_H
#include "codegen.h"

void virtualmachine(struct instruction *code, int flag);
#endif
